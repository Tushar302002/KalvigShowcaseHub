import React from 'react'

function CaseStudies() {
  return (
    <div>CaseStudies</div>
  )
}

export default CaseStudies