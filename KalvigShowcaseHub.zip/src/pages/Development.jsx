import React from 'react'

function Development() {
  return (
    <div>Development</div>
  )
}

export default Development