import React from 'react'

function Design() {
  return (
    <div>Design</div>
  )
}

export default Design